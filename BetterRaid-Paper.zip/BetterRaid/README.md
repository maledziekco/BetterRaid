# BetterRaid - Plugin dla Paper 1.21.x (w tym 1.21.4)

Kompletny projekt gotowy do otwarcia w **IntelliJ IDEA** i skompilowania pod najnowsze API Paper 1.21.x.

## 🚀 Jak zbudować plik .jar?
1. Otwórz ten folder w **IntelliJ IDEA**.
2. Upewnij się, że projekt używa **Java 21**.
3. Otwórz zakładkę Maven po prawej stronie (lub terminal) i uruchom komendę:
   ```bash
   mvn clean package
   ```
4. Gotowy plik `.jar` pojawi się w folderze `target/BetterRaid-1.0.0.jar`.
5. Wrzuć go do folderu `plugins/` na swoim serwerze Paper 1.21.x.

## ⚙️ Funkcje
- **Elitarne Moby**: Moby w rajdach mogą otrzymać potężny ekwipunek oraz zmieniony prefiks.
- **Boss Rajdu**: W ostatniej fali pojawia się zaawansowany Boss z osobnym paskiem zdrowia (BossBar).
- **Nagrody & Loot**: Po zakończeniu rajdu lub pokonaniu Bossa na ziemię wypada zdefiniowany loot.
- **Konfiguracja**: Pełna personalizacja w `config.yml`.
- **Komendy**:
  - `/betterraid reload` - Przeładowanie konfiguracji.
  - `/betterraid spawnboss` - Testowe zespawnowanie bossa.
