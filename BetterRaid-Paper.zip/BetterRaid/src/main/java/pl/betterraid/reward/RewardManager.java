package pl.betterraid.reward;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import pl.betterraid.BetterRaid;

import java.util.List;
import java.util.Map;
import java.util.Random;

public class RewardManager {

    private final BetterRaid plugin;
    private final Random random = new Random();

    public RewardManager(BetterRaid plugin) {
        this.plugin = plugin;
    }

    public void giveRaidRewards(Location location, List<Player> participants) {
        FileConfiguration config = plugin.getConfig();

        // Spawn guaranteed items
        List<Map<?, ?>> guaranteed = config.getMapList("rewards.guaranteed");
        for (Map<?, ?> itemMap : guaranteed) {
            String typeName = (String) itemMap.get("type");
            int amount = (int) itemMap.getOrDefault("amount", 1);
            try {
                Material mat = Material.valueOf(typeName.toUpperCase());
                ItemStack stack = new ItemStack(mat, amount);
                location.getWorld().dropItemNaturally(location, stack);
            } catch (Exception ignored) {}
        }

        // Spawn random items
        List<Map<?, ?>> randomLoot = config.getMapList("rewards.random-loot");
        for (Map<?, ?> itemMap : randomLoot) {
            String typeName = (String) itemMap.get("type");
            int amount = (int) itemMap.getOrDefault("amount", 1);
            double chance = (double) itemMap.getOrDefault("chance", 0.5);

            if (random.nextDouble() <= chance) {
                try {
                    Material mat = Material.valueOf(typeName.toUpperCase());
                    ItemStack stack = new ItemStack(mat, amount);
                    location.getWorld().dropItemNaturally(location, stack);
                } catch (Exception ignored) {}
            }
        }
    }
}
