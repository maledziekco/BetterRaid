package pl.betterraid.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Raider;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.raid.RaidFinishEvent;
import org.bukkit.event.raid.RaidSpawnWaveEvent;
import pl.betterraid.BetterRaid;

import java.util.List;

public class RaidListener implements Listener {

    private final BetterRaid plugin;

    public RaidListener(BetterRaid plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onWaveSpawn(RaidSpawnWaveEvent event) {
        List<Raider> raiders = event.getRaiders();
        for (Raider raider : raiders) {
            plugin.getRaidManager().enhanceRaider(raider);
        }

        // Check if this is final wave and boss is enabled
        if (plugin.getConfigManager().isBossEnabled() && event.getWave() >= event.getRaid().getMaxWaves()) {
            LivingEntity boss = plugin.getBossManager().spawnBoss(event.getPatrolLeader().getLocation());
            String msg = plugin.getConfigManager().getBossSpawnedMsg().replace("%boss%", boss.getCustomName());
            for (Player p : event.getRaid().getWinners()) {
                p.sendMessage(msg);
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof LivingEntity living && plugin.getBossManager().isBoss(living.getUniqueId())) {
            plugin.getBossManager().updateBossBar(living);
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Raider) {
            double mult = plugin.getConfigManager().getDamageMultiplier();
            event.setDamage(event.getDamage() * mult);
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (plugin.getBossManager().isBoss(entity.getUniqueId())) {
            plugin.getBossManager().removeBoss(entity);
            String msg = plugin.getConfigManager().getBossDefeatedMsg().replace("%boss%", entity.getCustomName());
            Bukkit.broadcastMessage(msg);

            // Give rewards at boss location
            plugin.getRewardManager().giveRaidRewards(entity.getLocation(), null);
        }
    }

    @EventHandler
    public void onRaidFinish(RaidFinishEvent event) {
        if (!event.getWinners().isEmpty()) {
            plugin.getRewardManager().giveRaidRewards(event.getRaid().getLocation(), event.getWinners());
        }
    }
}
